#' @title Data: Migration flows from SEA origins in 1965 to SEA destinations in 1970
#'
#' @description Matrix of migration flows among the 508 SEA (rows) in 1965 to
#'   508 SEA (columns) in 1970 of persons 5 years and older plus some leading
#'   variables describing the geographic and demographic attributes of the state
#'   economic areas.
#'
#' @docType data
#' @name mig
#' @usage \code{data(mig)}
#' @format A data-frame with 508 rows linked to the SEA origins and 8 variables
#'   plus 508 SEA destinations. The variables are as follows:
#'   \describe{
#'   \item{SEQID}{Internal sequence ID used to link to the spatial polygon
#'   data-frame \code{SEA}. Both the rows of \code{mig} and the polygons in
#'   \code{SEA} are sorted in the same order.}
#'   \item{POP}{Census population
#'   estimates of the SEA in 1980}
#'   \item{LONG}{Longitude of the SEA's centroids
#'   in millionth of degrees. Refer to the true longitudes of AK and HI}
#'   \item{LAT}{Latitude of the SEA's centroids in millionth of degrees. Refer
#'   to the true latitudes  of AK and HI}
#'   \item{SEA}{Factor of descriptive
#'   labels of the state ecomonic areas using the format "State.Number"}
#'   \item{SEAID}{Unique internal number of the SEAs}
#'   \item{STATE}{Internal
#'   number of the State within which each SEA is located}
#'   \item{URBRUR}{Factor
#'   designating each SEA as either 'rural' or 'urban'}
#'   \item{ME_01 \dots HI}{Columns of the 508 SEA destinations}
#'   }
#' @source The migration flows in \code{mig} were retrieved from the Census
#'   Bureau publication
#'   \url{https://www.census.gov/library/publications/1972/dec/pc-2-2e.html}
#' @examples
#' data(mig)
#' ## Build Vectorized Data-Frame
#' # great circle distance (km)
#' distSEA <- sp::spDists(as.matrix(mig[,c("LONG","LAT")]), longlat= TRUE)
#' # reshape matrix into vector
#' migVec <- matrix(as.matrix(mig[,9:516]), nrow = nrow(mig)^2)
#' # by stacking columns: from "1" to "1:95" etc.
#' disVec <- matrix(distSEA, nrow = nrow(distSEA)^2)
#' labelVec <- expand.grid(as.factor(mig$SEQID), as.factor(mig$SEQID))
#' popVec <- expand.grid(mig$POP, mig$POP)
#' ## Join into data-frame for migration analysis
#' migDf <- data.frame(labelVec,migVec,disVec,popVec)
#' names(migDf) <- c("ToID", "FromID", "mij", "dij", "ToPop","FromPop")
#' ## Gravity-type interaction model
#' mig1.glm <- glm(mij~log(dij)+log(ToPop)+log(FromPop), data=migDf,
#'                 family=quasipoisson, subset=(ToID!=FromID))
#' summary(mig1.glm)
#'
NULL
