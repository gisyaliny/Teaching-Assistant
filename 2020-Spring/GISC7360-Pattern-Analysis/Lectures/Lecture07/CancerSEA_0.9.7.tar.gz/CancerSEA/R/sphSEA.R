#' @title Map: SpatialPolygonsDataFrame of the 508 SEA
#'
#' @details Spatial polygons for the 508 State Economic Areas and some
#'   basic geographic attribute information for each SEA.
#'
#'   The polygons in the SpatialPolygonsDataFrame \code{sphSEA} follow the same
#'   order as the rows and columns of the migration matrix \code{\link[datasets]{mig}},
#'   which is identified by the data field \code{SEQID}.
#'
#'   The outlines of Alaska and Hawaii are shifted westwards off the coasts of
#'   Washington and California, respectively, to map all SEAs in a compact
#'   frame.
#'
#'   While SpatialPolygons objects possess internally calculated centroids and
#'   areas, the relocated SEAs of Alaska and Hawaii made it necessary to
#'   explicitly attach fields with their true centroids and areas to the
#'   associated data-frame.
#'
#'   A small artifical polygon is attached to Seattle's SEA and spatially linked
#'   to Alaska's SEA. Similarily a small polygon is attached to Los Angeles and
#'   linked to Hawaii. These artifical links establish physical connections
#'   for both spatially isolated states. ultimately, this allows building a spatial
#'   linkage graph based on seemingly contiguous boundaries. The artifical
#'   attachment of Alaska to Seattle and Hawaii to Los Angles were choosen because
#'   of their dominant migration flows, respectively. This allows to perform
#'   spatial analyses without unconnected polygons.
#'
#'   Suggested placements for a map legend are either \code{"bottomright"} or
#'   \code{"left"}
#'
#'   The polygons were digitized in the longitude and latitude format (see
#'
#'   \code{proj4string=CRS("+proj=longlat +ellps=WGS84")}).
#'
#'   Thus the SEAs are mapped in the Mercator projection.
#'
#'   To use this spatial polygons data-frame in other GIS sytems, one can export
#'   it as an ESRI shapefile with \code{maptools::writePolyShape(shpSEA,"SEA")},
#'   where \code{"SEA"} stand for the shapefile layer root name with the three
#'   file extensions \code{*.shp}, \code{*.shx} and \code{*.dbf}.
#'
#'
#' @docType data
#' @name shpSEA
#' @usage \code{data(shpSEA)}
#' @format The associated data-frame \code{shpSEA@data} has 508 rows with 11 columns:
#'   \describe{
#'   \item{ID}{An internal records identifier}
#'   \item{AREA}{Calculated area (not appropriate for AK and HI)}
#'   \item{SEQID}{Unique identifier following the same sequence as migration
#'   table \link{mig} and the cancer data \link{cancer}}
#'   \item{REALSQMILE}{True area in square miles}
#'   \item{REALLONG}{True longitude of SEA's centroid in millionth degrees}
#'   \item{REALLAT}{True latitude of SEA's centroid in millionth degrees}
#'   \item{NAMESEA}{Factor with long name and state of SEA}
#'   \item{MIGLABEL}{Factor with matching labels of SEA in migration table \link{mig}}
#'   \item{URBRUR}{Binary variable with \code{0=="rural"} and \code{1=="urban"}}
#'   \item{STATE}{Factor with two letters state codes}
#'   \item{REGION}{Factor with 9 US Census Regions}
#'   \item{FIPS}{FIPS code of SEA}
#'   }
#'@examples
#' library(maptools)
#' data(shpSEA); data(shpStates); data(shpNA)
#' SEA.box <- sp::bbox(shpSEA)             # bounding box for map frame
#' B <- spdep::poly2nb(shpSEA, queen=F)    # extract first order neighbors links
#' ## Plot three layers:
#' plot(shpNA, xlim=SEA.box[1,],ylim=SEA.box[2,], col=grey(0.7),
#'      bg="powderblue",axes=T)
#' plot(shpSEA, col=grey(0.5), border="beige", add=TRUE)
#' plot(shpStates, border="red", lwd=2, add=TRUE)
#' ## Add connectivity matrix
#' plot(B,coords=coordinates(shpSEA), pch=19, cex=0.6, col="yellow",
#'      lwd=1, add=TRUE)
#' title("First order links among the SEAs")
#' box()
NULL
