#' @title Data: DataFrame with Cancer Information for the 508 SEA
#'
#' @description This dataset contains spatio-temporal information by SEA on lung,
#'   bladder and prostate cancer for whites and blacks, males and females as
#'   well as the periods 1950-1969 and 1970-94, respectively. A few additional
#'   environmental and behavioral factors are also provided.
#'
#' @details The naming convention for the cancer statistics follows the schemata
#' \bold{C_RS_PP_SS}.
#'
#' \bold{Cancer type (letter \emph{C}):}
#'
#'   o   \bold{L:} Lung cancer
#'
#'   o   \bold{B:} Bladder cancer
#'
#'   o   \bold{P:} Prostate cancer
#'
#' \bold{Race (letter \emph{R}):}
#'
#'   o   \bold{B:} Black
#'
#'   o   \bold{W:} White
#'
#' \bold{Sex (letter \emph{S}):}
#'
#'   o   \bold{F:} Female
#'
#'   o   \bold{M:} Male
#'
#' \bold{Period (letters \emph{PP}):}
#'
#'   o   \bold{P1:} 1950 to 1969
#'
#'   o   \bold{P2:} 1970 to 1994
#'
#' \bold{Cancer statistic (letters \emph{SS}):}
#'
#'   o   \bold{CN:} Raw mortality count
#'
#'   o   \bold{LI:} Lower 95 percent confidence bound
#'
#'   o   \bold{UI:} Upper 95 percent confidence bound
#'
#'   o   \bold{EX:} Expected mortality count (indirectly age standardized)
#'
#'   o   \bold{RT:} Directly age-standardized mortality rate per 100,000 inhabitants
#'
#' @docType data
#' @name cancer
#' @usage \code{data(cancer)}
#' @format The data-frame \code{cancer} has 508 rows with 91 columns:
#'   \describe{
#'   \item{SEQID}{Sequence identifier and common link data field}
#'   \item{SEAID}{Unique internal number of the SEAs}
#'   \item{FIPS}{Unique census identifier}
#'   \item{SEANAME}{Factor with long name and state of SEA}
#'   \item{SEALABEL}{Factor with short label of SEA}
#'   \item{STATE}{Numeric code for each state}
#'   \item{NOFCNTY}{Number of counties establishing the aggregate SEA}
#'   \item{AREA}{True land area of each SEA}
#'   \item{POP1970}{Census population of each SEA in 1970}
#'   \item{POP1970LESS5YRS}{Census population less than 5 years old of each SEA in 1970}
#'   \item{POP1980}{Census population of each SEA in 1980}
#'   \item{POPATRISK1982}{Mid-period (1982) population at risk (white males 50+ years old)}
#'   \item{URBRUR}{Factor identifying whether a SEA is classified as"urban" or
#'                 "rural"}
#'   \item{TOBACCO}{Crude prevalence of current white male smokers in 1995. Data
#'                  are just available on the state-level but not on the SEA-level}
#'   \item{CAD_MD}{Median airborne cadmium concentration}
#'   \item{CAD_AV}{Average airborne cadmium concentration}
#'   \item{RAD_MD}{Median indoor radon concentration}
#'   \item{RAD_AV}{Average indoor radon concentration}
#'
#'   \item{LON}{True longitude of SEA's centroid in millionth degrees}
#'   \item{LAT}{True latitude of SEA's centroid in millionth degrees}
#'   \item{NAMESEA}{Factor with long name and state of SEA}
#'   \item{C_SR_PP_SS}{75 fields with cancer statistics following the naming
#'                     convention described in the "Details" section}
#'   }
#'@source The cancer statistics were retrieved in 2002 from
#'   \url{http://www.cancer.gov/atlasplus}.  This link is no longer active, however,
#'   related cancer statistics can be found now at \url{http://seer.cancer.gov/}.
#'
#'   The environmental \emph{radon} and \emph{cadmium} were retrieved from
#'   \url{http://www.stat.columbia.edu/~radon/} and
#'   \url{http://www2.lbl.gov/Science-Articles/Archive/radon-risk-website.html}.
#'
#'   The smoking rates of white males in 1995 were retrieved from
#'   \url{https://www.cdc.gov/brfss/brfssprevalence/}.
#'@examples
#' library(maptools)
#' data(shpSEA); data(shpStates); data(shpNA); data(cancer)
#' shpSEA <- sp::merge(shpSEA, cancer, by.x="SEQID", by.y="SEQID")
#' shpSEA$POPDEN <- shpSEA$POP1980/shpSEA$REALSQMILE
#'
#' SEA.box <- sp::bbox(shpSEA)             # bounding box for map frame
#' ## Plot three layers:
#' plot(shpNA, xlim=SEA.box[1,],ylim=SEA.box[2,], col=grey(0.7),
#'      bg="powderblue",axes=T)
#' mapBiPolar(shpSEA$POPDEN, shpSEA,
#'            break.value=median(shpSEA$POPDEN), neg.breaks=5, pos.breaks=4,
#'            legend.cex=0.9, legend.pos="bottomright",
#'            legend.title="POPDEN around Median",
#'            map.title="Population Density based on 1980 Census Population",
#'            add.to.map=T)
#' plot(shpStates, border="red", lwd=2, add=TRUE)
#' box()
NULL
