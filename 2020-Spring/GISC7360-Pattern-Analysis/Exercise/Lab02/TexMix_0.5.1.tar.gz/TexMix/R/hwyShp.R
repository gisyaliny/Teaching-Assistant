#' @title Major Highways in Dallas County, TX
#' @description Basic line layer in the longitude and latitude format (see
#'   \code{proj4string=CRS("+proj=longlat +ellps=WGS84")}).
#' @docType data
#' @name hwyShp
#' @examples
#' library(maptools)
#' validTractShp <- tractShp[!is.na(tractShp$BUYPOW), ]  # Remove 2 tracts with NA's
#' plot(tractShp, col="white", border="white", axes=T,
#'      main="Dallas Census Tracts with Food Deserts")
#' plot(validTractShp, col="ivory2", border="white", add=T)
#' plot(lakesShp, col="skyblue", border="skyblue",add=T)
#' plot(hwyShp, col="cornsilk3", lwd=3, add=T)
#' plot(foodDesertShp, border="magenta",lwd=2, add=T)
#' plot(bndShp, border="black", add=T)
#' box()
#'
NULL
